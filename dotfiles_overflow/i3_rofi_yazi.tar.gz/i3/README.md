Opened 2024-06-27
webref https://i3wm.org/docs/refcard.html


# Notes on i3

to resize   mod + r 
to logout   mod + shift + e

to kill app mod + shift + q



